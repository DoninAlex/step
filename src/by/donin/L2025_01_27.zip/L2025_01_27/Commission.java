package by.donin.L2025_01_27;

import java.util.Arrays;
import java.util.Random;

public class Commission {
    String[] doctors = {"Иванов", "Петров", "Сидоров", "Грибков", "Растеряев", "Глазко", "Шкет"};
    boolean valid = false;
    Dentist dentist;
    Oculist oculist;
    Surgeon surgeon;
    Psychiatrist psychiatrist;
    Therapist therapist;

    public Commission() {
        int specNumber = 5;
        if (specNumber <= doctors.length) {
            int[] staff = new int[specNumber];
            int ind = 0;
            int doc;
            Arrays.fill(staff, 1);
            Random random = new Random();
            while (ind < specNumber) {
                doc = random.nextInt(doctors.length);
                if (Arrays.binarySearch(staff, doc) < 0) {
                    staff[ind] = doc;
                    ind++;
                }
            }
            Dentist dentist = new Dentist();
            Oculist oculist = new Oculist();
            Surgeon surgeon = new Surgeon();
            Psychiatrist psychiatrist = new Psychiatrist();
            Therapist therapist = new Therapist();

            System.out.println("Члены комиссии:");
            for (int i = 0; i < staff.length; i++) {
                System.out.println(doctors[staff[i]]);
            }
            this.valid =  true;
        } else {
            this.valid =  false;
        }
    }

    public void test(Recruit recruit) {
        System.out.println("Dentist: " + dentist.test(recruit));
    }
}
