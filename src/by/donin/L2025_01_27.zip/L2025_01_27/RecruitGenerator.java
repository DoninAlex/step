package by.donin.L2025_01_27;

import java.util.Random;

public class RecruitGenerator {
    String[] firstNames = {"Василий", "Александр", "Геннадий", "Григорий"};
    String[] middleNames = {"Васильевич", "Александрович", "Геннадьевич", "Григорьевич"};
    String[] lastNames = {"Албанов", "Петрушкин", "Следаков", "Пупкин", "Зубов"};
    ArrayRecruits arrayRecruits = new ArrayRecruits();

    public Recruit generate() {
        Random random = new Random();
        int id = arrayRecruits.getSize();
        Recruit recruit = new Recruit(
                id,
                firstNames[random.nextInt(firstNames.length)],
                middleNames[random.nextInt(middleNames.length)],
                lastNames[random.nextInt(lastNames.length)],
                true,
                "",
                random.nextDouble(10.0),
                random.nextBoolean(),
                random.nextInt(10),
                random.nextInt(160) + 40
        );
        System.out.println(recruit.toString());
        return recruit;
    }
}
