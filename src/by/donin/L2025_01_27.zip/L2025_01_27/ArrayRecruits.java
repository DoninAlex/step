package by.donin.L2025_01_27;

public class ArrayRecruits {
    Recruit[] recruits = new Recruit[200];
    int recruitNumber = 0;

    public ArrayRecruits() {
        RecruitGenerator recruitGenerator = new RecruitGenerator();
    }

    public void add(Recruit recruit) {

//        Recruit recruits[recruitNumber] = new Recruit
    }

    public int getSize() {
        return recruitNumber;
    }

}
