package by.donin.L2025_01_27;

public class Main {
    public static void main(String[] args) {
        Recruit[] recruits = new Recruit[200];
        Commission commission = new Commission();
        if (commission.valid) {

            RecruitGenerator recruitGenerator = new RecruitGenerator();
            recruitGenerator.generate();

        }
    }
}
