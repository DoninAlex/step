package by.donin.H2025_02_05;

public class Library {
    private Book[] books;

    public Library() {
        books = new Book[0];
    }

    public void addBook(Book book) {
        int size = books.length;
        Book[] books1 = new Book[size + 1];
        for (int i = 0; i < size; i++) {
            books1[i] = books[i];
        }
        books1[size] = book;
        books = books1;
    }

    public void printBooks() {
        for (int i = 0; i < books.length; i++) {
            System.out.println(i + 1 + ". " + books[i].toString());
        }
    }

    public int findBookIndex(String title) {
        int index = -1;
        for (int i = 0; i < books.length; i++) {
            if (books[i].getTitle().equals(title)) {
                index = i;
                break;
            }
        }
        return index;
    }

    public Book getBook(int bookIndex) {
        return books[bookIndex];
    }

    public int getSize() {
        return books.length;
    }

    public void sortBooksByYear() {
        for (int i = 0; i < books.length; i++) {
            for (int j = 0; j < books.length - i - 1; j++) {
                if (books[j].getYear() < books[j + 1].getYear()) {
                    Book tmp = books[j];
                    books[j] = books[j + 1];
                    books[j + 1] = tmp;
                }
            }
        }
    }

    public void sortBooksByAuthorBirthYear() {
        for (int i = 0; i < books.length; i++) {
            for (int j = 0; j < books.length - i - 1; j++) {
                if (books[j].getAuthor().getBirthYear() < books[j + 1].getAuthor().getBirthYear()) {
                    Book tmp = books[j];
                    books[j] = books[j + 1];
                    books[j + 1] = tmp;
                }
            }
        }
    }

    public void sortBooksByTitle() {
        for (int i = 0; i < books.length; i++) {
            for (int j = 0; j < books.length - i - 1; j++) {
                if (books[j].getTitle().compareTo(books[j + 1].getTitle()) > 0) {
                    Book tmp = books[j];
                    books[j] = books[j + 1];
                    books[j + 1] = tmp;
                }
            }
        }
    }
}
