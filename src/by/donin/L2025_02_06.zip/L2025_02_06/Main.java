package by.donin.L2025_02_06;

public class Main {
    public static void main(String[] args) {

    }
}
