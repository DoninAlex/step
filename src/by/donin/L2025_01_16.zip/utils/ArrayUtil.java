package by.donin.utils;

import java.util.Arrays;
import java.util.Random;

public class ArrayUtil {

    private static final Random random = new Random();

    public static int[] generateIntArray(int size, int numberOrigin, int numberBound) {
        int[] array =  random.ints(size, numberOrigin, numberBound).toArray();
        System.out.println("Сгенерированный массив -> " + Arrays.toString(array));
        return array;
    }
}
