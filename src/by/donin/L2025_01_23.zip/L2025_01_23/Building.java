package by.donin.L2025_01_23;

public class Building {
    int windowNumber;
    int doorNumber;
    String material;
    String street;

    public Building(
        int windowNumber,
        int doorNumber,
        String material,
        String street
        ) {
       this.windowNumber = windowNumber;
       this.doorNumber = doorNumber;
       this.material = material;
       this.street = street;
    }

    String getDescription(){
        return "Здание имеет " + windowNumber + " окон, " +
                doorNumber + " дверей, находится на улице " +
                street + ", сделано из материала " + material + ".";
    }
}
